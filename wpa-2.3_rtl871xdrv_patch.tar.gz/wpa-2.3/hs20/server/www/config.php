<?php
$osu_root = "/home/user/hs20-server";
$osu_db = "sqlite:$osu_root/AS/DB/eap_user.db";
?>
